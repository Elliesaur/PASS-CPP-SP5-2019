#include "partmanager.h"

PartManager::PartManager()
{

}
