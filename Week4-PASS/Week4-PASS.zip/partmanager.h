#ifndef PARTMANAGER_H
#define PARTMANAGER_H


class PartManager
{
public:
    PartManager();
};

#endif // PARTMANAGER_H
