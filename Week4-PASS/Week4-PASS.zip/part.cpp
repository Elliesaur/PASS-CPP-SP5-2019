#include "part.h"

Part::Part(const std::shared_ptr<Computer> currentComputer)
    : _computer{currentComputer}
{

}
